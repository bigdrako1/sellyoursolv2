"""
🌙 Moon Dev's Trading System
""" 