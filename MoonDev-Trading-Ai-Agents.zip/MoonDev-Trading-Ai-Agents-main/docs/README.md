docs will come later

we are in alpha

for now you can see everything 

in these extremely detailed videos

of moon dev building out this package

- [ALL DOCUMENTATION VIDEOS](https://www.youtube.com/playlist?list=PLXrNVMjRZUJg4M4uz52iGd1LhXXGVbIFz)

anthropic, one of the leaders in ai said you need to understand every single line of code in these ai agent systems as its a new regime and there are so many pieces of alpha you can discover if you understand everything. opposed to just downloading code and just running it. this is why it's so important to invest your time in watching the above detailed videos. here is the article anthropic talked about it: https://www.anthropic.com/research/building-effective-agents