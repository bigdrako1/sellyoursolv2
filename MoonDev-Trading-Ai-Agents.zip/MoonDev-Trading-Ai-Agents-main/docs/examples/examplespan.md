the plan is to have an example for everything we build here in this folder, and ideally a video segment for it too that we can link to

essentially im building all this live on youtube, so as long as i take a minute out in the streams to review things i should be able to make super short, consumable docs for this and keep every example video and doc under 15 mins

